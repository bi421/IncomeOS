﻿from .pipeline import IngestPipeline
